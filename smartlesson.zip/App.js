import React from 'react';

const lessons = [
  { title: "Introduction to Algebra", subject: "Math", content: "Algebra is about finding the unknown or putting real-life variables into equations..." },
  { title: "Photosynthesis", subject: "Science", content: "Photosynthesis is the process used by plants to convert sunlight into energy..." }
];

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'Arial, sans-serif' }}>
      <h1 style={{ fontSize: '2.5rem', color: '#2c3e50' }}>SmartLesson</h1>
      <p style={{ fontSize: '1.25rem', color: '#34495e' }}>Welcome Josay Sayeh 👋</p>
      <div style={{ marginTop: '2rem' }}>
        {lessons.map((lesson, idx) => (
          <div key={idx} style={{ backgroundColor: '#ecf0f1', padding: '1rem', borderRadius: '10px', marginBottom: '1rem' }}>
            <h2>{lesson.title}</h2>
            <p><strong>Subject:</strong> {lesson.subject}</p>
            <p>{lesson.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;